import React from 'react'

function Feature4() {
  return (
    <div>Feature4</div>
  )
}

export default Feature4