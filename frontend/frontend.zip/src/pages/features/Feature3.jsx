import React from 'react'

function Feature3() {
  return (
    <div>Feature3</div>
  )
}

export default Feature3