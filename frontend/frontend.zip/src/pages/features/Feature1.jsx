import React from "react";

function Feature1() {
  return <div>Feature1</div>;
}

export default Feature1;
