import React from "react";

function Feature2() {
  return <div>Feature2</div>;
}

export default Feature2;
